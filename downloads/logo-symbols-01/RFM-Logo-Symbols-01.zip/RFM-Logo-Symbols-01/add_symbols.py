"""Embed exact supplied logo geometry into a glyf TTF with COLR v0/CPAL.
No RF Dewi outlines or Unicode letters are replaced. Geometry must be supplied
from the actual vector logo, not synthesized from a font or screenshot.
"""
from pathlib import Path
import json
from fontTools.colorLib.builder import buildCOLR,buildCPAL

MAP=json.loads(Path(__file__).with_name('symbol-map.json').read_text())

def add_symbols(font, geometry, orange, rim=None):
 """geometry = {'mini': {'mark': TTGlyph, 'background': TTGlyph, 'advance': int},
                  'full': {'mark': TTGlyph, 'background': TTGlyph, 'advance': int}}.
 Geometry is already fitted to cap height, common canvas, upright, with lsb >= 0.
 Each variant of a given form keeps the same mark position and advance.
 orange is the actual source-logo RGBA, floats in [0,1].
 """
 if 'COLR' in font or 'CPAL' in font:raise ValueError('Existing color tables require merging; refusing replacement')
 cmap=font.getBestCmap()
 active=[item for item in MAP if item['form'] in geometry]
 if any(int(item['unicode'][2:],16) in cmap for item in active):raise ValueError('Private-use mapping already occupied')
 order=list(font.getGlyphOrder());color={};glyf=font['glyf'];hmtx=font['hmtx']
 def put(name,glyph,advance):
  if name in order:raise ValueError('Glyph name collision: '+name)
  import copy
  glyph=copy.deepcopy(glyph);glyph.recalcBounds(glyf)
  glyf[name]=glyph;hmtx[name]=(advance,getattr(glyph,'xMin',0));order.append(name)
 for form,d in geometry.items():
  put('rfm_'+form+'_mark',d['mark'],d['advance'])
  put('rfm_'+form+'_background',d['background'],d['advance'])
  if 'rim' in d:put('rfm_'+form+'_rim',d['rim'],d['advance'])
 for item in active:
  form=item['form'];name=item['glyph'];d=geometry[form]
  # Fallback is the actual monochrome logo; unsupported COLR loses fixed colors/background.
  put(name,d.get('fallback',d['mark']) if 'orange-background' in item['color'] else d['mark'],d['advance'])
  layers=[]
  if 'orange-background' in item['color']:
   layers.append(('rfm_'+form+'_background',0))
   if 'rim' in d:layers.append(('rfm_'+form+'_rim',3))
  layers.append(('rfm_'+form+'_mark',2 if item['color'].startswith('black') else 1))
  color[name]=layers
  for table in font['cmap'].tables:
   if table.isUnicode() and table.format in [4,12]:table.cmap[int(item['unicode'][2:],16)]=name
 font.setGlyphOrder(order)
 glyf.glyphOrder=order
 font['COLR']=buildCOLR(color,version=0,glyphMap=font.getReverseGlyphMap())
 palette=[tuple(orange),(1,1,1,1),(0,0,0,1)]
 if rim is not None:palette.append(tuple(rim))
 font['CPAL']=buildCPAL([palette])
 font['maxp'].numGlyphs=len(order)
 return font

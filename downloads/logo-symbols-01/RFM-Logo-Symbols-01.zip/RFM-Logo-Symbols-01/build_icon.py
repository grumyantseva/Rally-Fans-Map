"""Embed uploaded Logo icon.svg, including its exact two orange colors and strokes.
Run --svg /path/to/Logo icon.svg --base-dir /path/to/Trial01/fonts.
Only the three available icon symbols are mapped. Full-logo codepoints stay unmapped.
"""
from pathlib import Path
from copy import deepcopy
import argparse,xml.etree.ElementTree as ET,json,hashlib,math
import pathops as po
from fontTools.svgLib.path import SVGPath
from fontTools.pens.recordingPen import RecordingPen
from fontTools.pens.ttGlyphPen import TTGlyphPen
from fontTools.pens.cu2quPen import Cu2QuPen
from fontTools.ttLib import TTFont
from PIL import Image,ImageDraw,ImageFont
from add_symbols import add_symbols
R=Path(__file__).resolve().parent
NS='http://www.w3.org/2000/svg';ET.register_namespace('',NS)

def rgba(s):
 s=s.lstrip('#');return tuple(int(s[i:i+2],16)/255 for i in [0,2,4])+(1,)

def svgpath(element):
 element=deepcopy(element)
 transform=element.attrib.get('transform','')
 if transform.startswith('rotate('):
  from fontTools.misc.transform import Transform
  values=[float(v) for v in transform[7:-1].replace(',',' ').split()]
  assert len(values)==3
  angle,cx,cy=values
  matrix=Transform().translate(cx,cy).rotate(math.radians(angle)).translate(-cx,-cy)
  element.attrib['transform']='matrix('+','.join(str(v) for v in matrix)+')'
 root=ET.Element('{'+NS+'}svg',{'viewBox':'0 0 592 591'});root.append(element)
 svg=SVGPath.fromstring(ET.tostring(root));p=po.Path();svg.draw(p.getPen());return p

def union(parts):
 p=parts[0]
 for q in parts[1:]:p=po.op(p,q,po.PathOp.UNION,clockwise=True)
 return po.simplify(p,clockwise=True)

def glyph(p):
 # Common square canvas; retain original padding and proportions in all variants.
 scale=700/591;p=p.transform(scale,0,0,-scale,40,700)
 pen=TTGlyphPen(None);p.draw(Cu2QuPen(pen,max_err=.2));return pen.glyph()

def extract(svg):
 root=ET.parse(svg).getroot();assert root.attrib['viewBox']=='0 0 592 591'
 bg=[];mark=[];rim=[];base_color=None;rim_color=None
 for element in root.iter():
  tag=element.tag.split('}')[-1]
  if tag not in ['rect','circle','path']:continue
  # This exact SVG has a duplicate rect in defs as its clip shape; ignore it.
  if element.attrib.get('fill')=='white' and tag=='rect':continue
  fill=element.attrib.get('fill',root.attrib.get('fill','black'));stroke=element.attrib.get('stroke','none')
  if fill not in ['none','white'] and tag=='rect':
   p=svgpath(element);bg.append(p);base_color=fill
  elif fill=='white':mark.append(svgpath(element))
  if stroke!='none':
   p=svgpath(element);p.stroke(float(element.attrib['stroke-width']),po.LineCap.BUTT_CAP,po.LineJoin.MITER_JOIN,4);p.convertConicsToQuads(.1)
   if stroke=='white':mark.append(p)
   else:rim.append(p);rim_color=stroke
 assert len(bg)==1 and len(rim)==1 and len(mark)==5
 # The supplied clipPath is the same rounded rect as the background itself.
 clipping=root.find('.//{'+NS+'}clipPath/{'+NS+'}rect')
 background=root.find('.//{'+NS+'}g/{'+NS+'}rect')
 for key in ['x','y','width','height','rx']:assert clipping.attrib[key]==background.attrib[key]
 background=union(bg);markpath=union(mark);rimpath=union(rim)
 fallback=po.op(union([background,rimpath]),markpath,po.PathOp.DIFFERENCE,clockwise=True)
 geometry={'mini':{'background':glyph(background),'mark':glyph(markpath),'rim':glyph(rimpath),'fallback':glyph(fallback),'advance':round(700*592/591+80)}}
 return geometry,rgba(base_color),rgba(rim_color)

def names(font,key):
 italic='Italic' in key;black='Black' in key;ext='Extended' in key;width='Extended' if ext else 'Expanded'
 family='RF Dewi RFM Logo 01 '+width
 style='Black Italic' if italic else ('Black' if black else 'Bold')
 legacy_family=family+(' Black' if black else '');legacy_style='Italic' if italic else ('Regular' if black else 'Bold')
 values={1:legacy_family,2:legacy_style,3:'RFDewiRFMLogo01-'+key+'-0.002',4:family+' '+style,5:'Version 0.002; RF Dewi adjustment trial with RFM icon',6:'RFDewiRFMLogo01-'+key,16:family,17:style,10:'RF Dewi derivative trial. Original font design attribution retained. User-supplied Rally Fans Map icon embedded at U+E000-E002.'}
 font['name'].names=[n for n in font['name'].names if n.nameID not in values]
 for nid,value in values.items():
  font['name'].setName(value,nid,3,1,0x409);font['name'].setName(value,nid,1,0,0)

def preview(paths):
 im=Image.new('RGB',(2000,1600),'#172026');d=ImageDraw.Draw(im);label=ImageFont.load_default(size=25)
 d.text((55,35),'RALLY FANS MAP / ACTUAL FONT GLYPHS / U+E000-E002',font=label,fill='#f0f2ef')
 for col,(cp,title,back) in enumerate([(0xe000,'E000 / ORANGE', '#253138'),(0xe001,'E001 / WHITE', '#253138'),(0xe002,'E002 / BLACK', '#e8ebed')]):
  x=55+col*650;d.text((x,95),title,font=label,fill='#b4c6ce')
  for row,fp in enumerate(paths):
   y=165+row*445
   d.rounded_rectangle((x,y,x+590,y+350),radius=14,fill=back)
   font=ImageFont.truetype(str(fp),385)
   d.text((x+140,y+310),chr(cp),font=font,embedded_color=True,anchor='ls')
   d.text((x,y+365),fp.stem.replace('RFDewiRFMLogo01-',''),font=ImageFont.load_default(size=21),fill='#b4c6ce')
 d.text((55,1545),'LOGOS ARE UPRIGHT IN ALL THREE FACES / ORIGINAL SVG COLORS / NO FULL-LOGO PLACEHOLDERS',font=ImageFont.load_default(size=20),fill='#b4c6ce')
 im.save(R/'icon-symbols.png')

def main():
 a=argparse.ArgumentParser();a.add_argument('--svg',type=Path,required=True);a.add_argument('--base-dir',type=Path,required=True);args=a.parse_args()
 for d in ['fonts','assets']:(R/d).mkdir(exist_ok=True)
 geometry,orange,rim=extract(args.svg);files=[];checks=[]
 (R/'assets/Logo-icon-original.svg').write_bytes(args.svg.read_bytes())
 for key in ['ExpandedBold','ExtendedBlack','ExpandedBlackItalic']:
  source=args.base_dir/f'RFDewiRFMTrial01-{key}.ttf';font=TTFont(source,recalcTimestamp=False)
  oldmap=font.getBestCmap().copy();oldout={n:font['glyf'][n].compile(font['glyf']) for n in font.getGlyphOrder()};oldmetrics=font['hmtx'].metrics.copy()
  font=add_symbols(font,geometry,orange,rim);names(font,key);font['head'].created=font['head'].modified=3800000000;out=R/'fonts'/f'RFDewiRFMLogo01-{key}.ttf';font.save(out)
  web=TTFont(out,recalcTimestamp=False);web.flavor='woff2';web.save(out.with_suffix('.woff2'))
  f=TTFont(out);assert set(f.getBestCmap())==set(oldmap)|set(range(0xe000,0xe003));assert not any(cp in f.getBestCmap() for cp in range(0xe003,0xe006))
  for n,raw in oldout.items():assert f['glyf'][n].compile(f['glyf'])==raw and f['hmtx'][n]==oldmetrics[n]
  assert len(f['COLR'].ColorLayers)==3;assert TTFont(out.with_suffix('.woff2')).getBestCmap()==f.getBestCmap()
  checks.append({'file':out.name,'letters_outlines_and_metrics_unchanged':True,'mapped_characters':len(f.getBestCmap()),'COLR_v0_layers':3,'palette_hex':['#FF440D','#FFFFFF','#000000','#FF6228'],'woff2_roundtrip':True,'sha256':hashlib.sha256(out.read_bytes()).hexdigest()});files.append(out)
 # Fixed colors/transparent backgrounds verified by rendering the output font itself.
 masks=[]
 for file in files:
  font=ImageFont.truetype(str(file),591)
  for cp in range(0xe000,0xe003):
   im=Image.new('RGBA',(650,650),(0,0,0,0));ImageDraw.Draw(im).text((0,0),chr(cp),font=font,embedded_color=True)
   data=list(im.get_flattened_data());colors=set(data)
   if cp==0xe000:
    assert (255,68,13,255) in colors and (255,98,40,255) in colors and (255,255,255,255) in colors
   elif cp==0xe001:assert (255,255,255,255) in colors and (255,68,13,255) not in colors
   else:assert (0,0,0,255) in colors and (255,68,13,255) not in colors
   assert (0,0,0,0) in colors
  # Logo glyph data identical between upright and italic face.
  f=TTFont(file);masks.append({n:f['glyf'][n].compile(f['glyf']) for n in ['rfmIconOrange','rfmIconWhite','rfmIconBlack']})
 assert masks[0]==masks[1]==masks[2]
 (R/'logo-checks.json').write_text(json.dumps({'input_svg_sha256':hashlib.sha256(args.svg.read_bytes()).hexdigest(),'actual_logo_embedded':True,'logos_identical_upright_across_faces':True,'fixed_colors_and_transparency_rendered':True,'full_logo':'pending SVG; U+E003-E005 not mapped','fonts':checks},ensure_ascii=False,indent=2))
 preview(files);print('Built 3 fonts with 3 exact icon symbols each; original letters unchanged; full logo not fabricated')

if __name__=='__main__':main()

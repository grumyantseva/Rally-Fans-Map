"""RFM Sans original outline study v0.002. No font outlines imported."""
from pathlib import Path
import argparse, json, hashlib, base64, html, zipfile
import pathops as po
from fontTools.fontBuilder import FontBuilder
from fontTools.ttLib import TTFont
from fontTools.pens.ttGlyphPen import TTGlyphPen
from fontTools.pens.cu2quPen import Cu2QuPen
from fontTools.pens.recordingPen import RecordingPen
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.feaLib.builder import addOpenTypeFeaturesFromString
from PIL import Image,ImageDraw,ImageFont
R=Path(__file__).resolve().parent
TEXTS=['RALLY FANS MAP','РАЛЛИ СОРТАВАЛА','КОМПАНЬОН','ПРОГРАММА НА СЕГОДНЯ','Альметьевск','0123456789','25–26 СЕНТЯБРЯ']
CHARS=sorted(set(''.join(TEXTS)),key=ord)
ALIAS={'А':'A','М':'M','Н':'H','Р':'P','В':'B','О':'O','С':'C'}
VERSION='0.002'

def path(cmd):
 p=po.Path();pen=p.getPen()
 for op,pts in cmd:getattr(pen,op)(*pts)
 return p

def poly(pts):return path([('moveTo',[pts[0]]),*[('lineTo',[pt]) for pt in pts[1:]],('closePath',[])])
def rect(x,y,w,h):return poly([(x,y),(x+w,y),(x+w,y+h),(x,y+h)])
def union(*ps):
 p=ps[0]
 for q in ps[1:]:p=po.op(p,q,po.PathOp.UNION,clockwise=True)
 return p

def diff(p,q):return po.op(p,q,po.PathOp.DIFFERENCE,clockwise=True)
def clip(p,x,y,w,h):return po.op(p,rect(x,y,w,h),po.PathOp.INTERSECTION,clockwise=True)

def roundbox(x,y,w,h,rx,ry=None):
 ry=rx if ry is None else ry;rx=min(rx,w/2);ry=min(ry,h/2);k=.5522847498307936
 return path([('moveTo',[(x+rx,y)]),('lineTo',[(x+w-rx,y)]),('curveTo',[(x+w-rx+k*rx,y),(x+w,y+ry-k*ry),(x+w,y+ry)]),('lineTo',[(x+w,y+h-ry)]),('curveTo',[(x+w,y+h-ry+k*ry),(x+w-rx+k*rx,y+h),(x+w-rx,y+h)]),('lineTo',[(x+rx,y+h)]),('curveTo',[(x+rx-k*rx,y+h),(x,y+h-ry+k*ry),(x,y+h-ry)]),('lineTo',[(x,y+ry)]),('curveTo',[(x,y+ry-k*ry),(x+rx-k*rx,y),(x+rx,y)]),('closePath',[])])

def strokep(cmd,t,cap=po.LineCap.BUTT_CAP):
 p=path(cmd);p.stroke(t,cap,po.LineJoin.ROUND_JOIN,4);p.convertConicsToQuads(.15);return p

def line(pts,t):return strokep([('moveTo',[pts[0]]),*[('lineTo',[pt]) for pt in pts[1:]]],t)

def dshape(x,y,w,h,v):
 # Left upright + rounded right bowl. A: flat shoulders; B: elliptical end.
 rx=185 if v=='A' else w*.53;ry=h/2 if v=='B' else min(175,h/2)
 return roundbox(x,y,w,h,rx,ry)

def design(char,v):
 c=ALIAS.get(char,char);wide=v=='B';t=132;small=char.islower();t=104 if small else t
 w=(800 if wide else 760);H=700;xh=530
 def stroke(pts,width=t):return line(pts,width)
 def draw(cmd,width=t):return strokep(cmd,width)
 def rb(x,y,ww,hh):return roundbox(x,y,ww,hh,ww/2 if wide else 195,hh/2 if wide else 195)
 def strokeclosed(center,th):
  center.stroke(th,po.LineCap.BUTT_CAP,po.LineJoin.ROUND_JOIN,4);center.convertConicsToQuads(.15)
  return po.simplify(center,clockwise=True)
 def ring(x,y,ww,hh,th=t):
  rx=(ww-th)/2 if wide else max(15,195-th/2)
  ry=(hh-th)/2 if wide else max(15,195-th/2)
  return strokeclosed(roundbox(x+th/2,y+th/2,ww-th,hh-th,rx,ry),th)
 def dbowl(x,y,ww,hh):
  # A closed centerline gives equal normal thickness through straight and curved sections.
  left=x+t/2;right=x+ww-t/2;bottom=y+t/2;top=y+hh-t/2
  rx=(ww-t)*.55 if wide else 125
  ry=(hh-t)/2
  k=.5522847498307936
  center=path([('moveTo',[(left,bottom)]),('lineTo',[(right-rx,bottom)]),('curveTo',[(right-rx+k*rx,bottom),(right,bottom+ry-k*ry),(right,bottom+ry)]),('curveTo',[(right,top-ry+k*ry),(right-rx+k*rx,top),(right-rx,top)]),('lineTo',[(left,top)]),('closePath',[])])
  return strokeclosed(center,t)
 if c=='A':
  if wide:g=union(stroke([(65,0),(w/2,670),(w-65,0)],126),rect(175,218,w-350,120))
  else:g=union(stroke([(65,0),(w*.46,665),(w*.54,665),(w-65,0)],126),rect(175,232,w-350,120))
  g=clip(g,-100,0,w+200,700)
 elif c in ['F','L','Е','Г','П','H','Н','Т']:
  ww=w if c not in ['F','Г','Е'] else w-55
  if c=='F':g=union(rect(0,0,t,700),rect(0,576,ww,124),rect(0,302,ww-85,124))
  elif c=='L':g=union(rect(0,0,t,700),rect(0,0,ww,124))
  elif c=='Е':g=union(rect(0,0,t,700),rect(0,576,ww,124),rect(0,0,ww,124),rect(0,293,ww-80,114))
  elif c=='Г':g=union(rect(0,0,t,700),rect(0,576,ww,124))
  elif c=='П':g=union(rect(0,0,t,700),rect(ww-t,0,t,700),rect(0,576,ww,124))
  elif c in ['H','Н']:g=union(rect(0,0,t,700),rect(ww-t,0,t,700),rect(0,290,ww,120))
  else:g=union(rect(0,576,ww,124),rect((ww-t)/2,0,t,700))
 elif c in ['M','м']:
  hh=xh if small else H;ww=650 if small else w+55
  # Two visibly different structures: A high central junction; B deep central valley.
  if wide:pts=[(t/2,0),(t/2,hh-t/2),(ww/2,105 if not small else 80),(ww-t/2,hh-t/2),(ww-t/2,0)]
  else:pts=[(t/2,0),(t/2,hh-t/2),(ww/2,260 if not small else 195),(ww-t/2,hh-t/2),(ww-t/2,0)]
  g=clip(stroke(pts,t if small else 128),0,0,ww,hh)
 elif c in ['N','И']:
  ww=w;g=union(rect(0,0,t,H),rect(ww-t,0,t,H),stroke([(t*.65,640 if c=='N' else 60),(ww-t*.65,60 if c=='N' else 640)],122))
  g=clip(g,0,0,ww,H)
 elif c=='Y':g=clip(union(stroke([(40,700),(w/2,342),(w-40,700)],126),rect((w-t)/2,0,t,350)), -50,0,w+100,700)
 elif c in ['Л','л']:
  hh=xh if small else H;ww=610 if small else w
  if wide:
   g=union(stroke([(40,0),(ww/2,hh-30),(ww-40,0)],t if small else 126))
  else:
   g=union(draw([('moveTo',[(0,62)]),('curveTo',[(155,62),(160,170),(210,hh-62)]),('lineTo',[(ww-t/2,hh-62)]),('lineTo',[(ww-t/2,0)])]))
  g=clip(g,-70,0,ww+140,hh)
 elif c in ['К','к']:
  ww=600 if small else w;hh=xh if small else H
  if wide:
   branch=draw([('moveTo',[(ww-15,hh)]),('curveTo',[(ww*.65,hh*.80),(ww*.52,hh*.55),(t*.7,hh*.47)])],t if small else 124)
   leg=draw([('moveTo',[(ww*.39,hh*.48)]),('curveTo',[(ww*.68,hh*.38),(ww*.73,hh*.15),(ww-10,0)])],t if small else 124)
  else:
   branch=stroke([(ww-15,hh),(ww*.42,hh*.49),(t*.65,hh*.49)],t if small else 124)
   leg=stroke([(ww*.42,hh*.49),(ww-10,0)],t if small else 124)
  g=clip(union(rect(0,0,t,hh),branch,leg),0,0,ww+70,hh)
 elif c=='Д':
  if wide: body=stroke([(100,65),(w/2,665),(w-100,65)],124)
  else:body=union(stroke([(100,65),(235,638),(w-120,638),(w-120,65)],126))
  g=union(clip(body,0,65,w,635),roundbox(0,-5,w,124,12),rect(0,-125,124,180),rect(w-124,-125,124,180))
 elif c in ['O','0','C','с','е']:
  ww=610 if small else (710 if c=='0' else w);hh=xh+18 if small else 720;yy=-9 if small else -10
  g=ring(0,yy,ww,hh)
  if c in ['C','с']:
   # Open counters with horizontal cuts rather than diagonal slices.
   opening=.34*hh if wide else .39*hh
   g=diff(g,rect(ww*.60,yy+(hh-opening)/2,ww*.5,opening))
  if c=='е':
   g=diff(g,rect(ww*.64,yy+hh*.25,ww*.5,hh*.19))
   g=union(g,rect(t*.6,hh*.45,ww-t*.85,96))
 elif c=='S':
  ww=w-30
  if wide:cmd=[('moveTo',[(ww-50,590)]),('curveTo',[(ww-190,740),(60,700),(66,525)]),('curveTo',[(70,420),(210,410),(ww/2,355)]),('curveTo',[(ww-180,300),(ww-62,285),(ww-66,175)]),('curveTo',[(ww-70,-15),(130,-5),(45,125)])]
  else:cmd=[('moveTo',[(ww-50,595)]),('curveTo',[(ww-105,656),(ww-160,644),(ww/2,644)]),('curveTo',[(150,644),(66,628),(66,520)]),('curveTo',[(66,430),(180,408),(ww/2,355)]),('curveTo',[(ww-180,301),(ww-66,280),(ww-66,180)]),('curveTo',[(ww-66,66),(ww-150,56),(ww/2,56)]),('curveTo',[(180,56),(100,50),(45,120)])]
  g=draw(cmd,128)
 elif c in ['P','R','B','Ь','Я','ь','в','Б']:
  hh=xh if small else H;ww=570 if small else w-35
  stem=rect(0,0,t,hh)
  if c in ['P','R','Я']:g=union(stem,dbowl(0,290,ww,410))
  elif c in ['Ь','ь','Б']:
   bowlh=hh*.59+14
   g=union(stem,dbowl(0,-8,ww,bowlh))
   if c=='Б':g=union(g,rect(0,576,ww-20,124))
  else:
   # Two bowls share exactly one t-high middle band.
   mid=hh/2
   g=union(stem,dbowl(0,0,ww,mid+t/2),dbowl(0,mid-t/2,ww-25,hh-mid+t/2))
  if c=='R':
   if wide:leg=draw([('moveTo',[(ww*.48,345)]),('curveTo',[(ww*.73,285),(ww*.71,135),(ww+20,0)])],126)
   else:leg=stroke([(ww*.48,340),(ww+10,0)],126)
   g=clip(union(g,leg),0,0,ww+100,700)
  if c=='Я':
   g=g.transform(-1,0,0,1,ww,0)
   if wide:leg=draw([('moveTo',[(ww*.51,345)]),('curveTo',[(ww*.27,285),(ww*.30,135),(-10,0)])],126)
   else:leg=stroke([(ww*.52,340),(-10,0)],126)
   g=clip(union(g,leg),-100,0,ww+200,700)
 elif c=='т':g=union(rect(0,xh-100,600,100),rect(248,0,104,xh))
 elif c=='–':g=rect(0,287,600,110)
 elif c=='1':
  if wide:g=union(stroke([(75,540),(325,650)],124),rect(260,0,132,700))
  else:g=union(stroke([(65,525),(320,638)],124),rect(260,0,132,700),rect(70,0,560,124))
 elif c=='4':
  ww=710
  if wide:g=union(stroke([(450,700),(65,235),(710,235)],124),rect(485,0,132,700))
  else:g=union(stroke([(505,700),(65,235),(710,235)],124),rect(485,0,132,700))
  g=clip(g,-30,0,800,700)
 elif c=='7':
  if wide:g=union(rect(0,576,710,124),draw([('moveTo',[(640,610)]),('curveTo',[(515,420),(410,220),(340,0)])],132))
  else:g=union(rect(0,576,710,124),stroke([(640,610),(275,0)],132))
  g=clip(g,-30,0,800,700)
 elif c=='2':
  ww=710
  if wide:cmd=[('moveTo',[(65,540)]),('curveTo',[(80,705),(635,740),(644,535)]),('curveTo',[(660,400),(440,310),(95,65)])]
  else:cmd=[('moveTo',[(65,535)]),('curveTo',[(65,645),(180,646),(350,646)]),('curveTo',[(545,646),(644,635),(644,525)]),('curveTo',[(644,425),(570,375),(390,265)]),('lineTo',[(95,65)])]
  g=union(draw(cmd,128),rect(30,0,680,124));g=clip(g,-20,0,800,720)
 elif c in ['3','5','6','8','9']:
  ww=710
  if c=='8':
   g=union(ring(0,-10,ww,426),ring(15,284,ww-30,426))
  elif c=='3':
   if wide:cmd=[('moveTo',[(55,588)]),('curveTo',[(220,720),(645,710),(645,525)]),('curveTo',[(645,400),(510,350),(315,350)]),('curveTo',[(510,350),(645,305),(645,175)]),('curveTo',[(645,-10),(215,-10),(50,115)])]
   else:cmd=[('moveTo',[(60,595)]),('curveTo',[(135,650),(220,646),(350,646)]),('curveTo',[(540,646),(645,630),(645,525)]),('curveTo',[(645,405),(515,350),(300,350)]),('curveTo',[(520,350),(645,300),(645,175)]),('curveTo',[(645,65),(535,54),(350,54)]),('curveTo',[(220,54),(130,50),(55,110)])]
   g=draw(cmd,128)
  elif c=='5':
   cmd=[('moveTo',[(660,638)]),('lineTo',[(115,638)]),('lineTo',[(90,375)]),('curveTo',[(260,415),(640,450),(644,205)]),('curveTo',[(655,-5),(180,-5),(55,115)])]
   if not wide:cmd=[('moveTo',[(660,638)]),('lineTo',[(115,638)]),('lineTo',[(95,375)]),('lineTo',[(360,375)]),('curveTo',[(540,375),(644,330),(644,205)]),('curveTo',[(644,70),(535,54),(350,54)]),('curveTo',[(220,54),(130,50),(55,110)])]
   g=draw(cmd,128)
  elif c=='6':
   if wide:cmd=[('moveTo',[(625,615)]),('curveTo',[(470,730),(66,725),(66,385)]),('lineTo',[(66,235)]),('curveTo',[(66,-10),(645,-15),(645,230)]),('curveTo',[(645,435),(260,465),(80,325)])]
   else:cmd=[('moveTo',[(630,615)]),('curveTo',[(560,650),(500,646),(350,646)]),('curveTo',[(150,646),(66,590),(66,390)]),('lineTo',[(66,225)]),('curveTo',[(66,75),(160,54),(350,54)]),('curveTo',[(545,54),(645,85),(645,230)]),('curveTo',[(645,365),(545,400),(350,400)]),('curveTo',[(220,400),(135,375),(80,325)])]
   g=draw(cmd,128)
  else:
   q,_=design('6',v);lo=q.bounds[0];g=q.transform(-1,0,0,-1,ww+lo,700)
 else:raise ValueError(char)
 # Align extrema without distorting widths. Straight/diagonal stroke compensation is explicit.
 xmin,ymin,xmax,ymax=g.bounds
 sb=55 if char not in ['Л','л','A','А'] else 48
 g=g.transform(1,0,0,1,sb-xmin,0)
 advance=round(xmax-xmin+2*sb)
 if c in '0123456789':
  target=850
  g=g.transform(1,0,0,1,(target-advance)/2,0);advance=target
 return po.simplify(g,clockwise=True),advance


def seed():
 for v in 'AB':
  glyphs={}
  for c in CHARS:
   rec=RecordingPen()
   if c==' ':adv=300
   else:g,adv=design(c,v);g.draw(rec)
   glyphs[f'uni{ord(c):04X}']={'unicode':ord(c),'advance':adv,'commands':rec.value}
  data={'family':f'RFM Sans Study {v} R2','version':VERSION,'upm':1000,'ascender':950,'descender':-250,'cap_height':700,'x_height':530,'glyphs':glyphs}
  (R/'sources'/f'{v}.json').write_text(json.dumps(data,ensure_ascii=False,indent=2))
  (R/'sources'/f'{v}-kern.fea').write_text('languagesystem DFLT dflt; languagesystem latn dflt; languagesystem cyrl dflt; feature kern {\n'+''.join(f'pos uni{ord(a):04X} uni{ord(b):04X} {value};\n' for a,b,value in [('R','A',-25),('L','Y',-60),('F','A',-45),('M','A',-10),('А','Л',-25),('Т','А',-45),('А','Т',-40),('Р','А',-30),('Г','А',-35),('К','О',-15),('Л','Ь',-10)])+'} kern;\n')

def replay(commands,pen):
 for op,points in commands:getattr(pen,op)(*[tuple(pt) if pt is not None else None for pt in points])

def build(v):
 data=json.loads((R/'sources'/f'{v}.json').read_text());gl=data['glyphs'];fb=FontBuilder(data['upm'],isTTF=True)
 fb.setupGlyphOrder(['.notdef',*gl]);fb.setupCharacterMap({d['unicode']:name for name,d in gl.items()})
 nd=TTGlyphPen(None);p=diff(rect(60,0,620,700),rect(180,120,380,460));p.draw(nd)
 outlines={'.notdef':nd.glyph()};metrics={'.notdef':(740,60)}
 for name,d in gl.items():
  pen=TTGlyphPen(None);replay(d['commands'],Cu2QuPen(pen,max_err=.4,reverse_direction=False))
  glyph=pen.glyph();outlines[name]=glyph
  if d['commands']:
   pp=path(d['commands']);lsb=round(pp.bounds[0])
  else:lsb=0
  metrics[name]=(d['advance'],lsb)
  svg=SVGPathPen(None);replay(d['commands'],svg)
  (R/'svg'/v/f'{name}.svg').write_text(f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 -950 {d["advance"]} 1200"><title>{name}</title><path transform="scale(1,-1)" d="{svg.getCommands()}"/></svg>')
 fb.setupGlyf(outlines);fb.setupHorizontalMetrics(metrics);fb.setupHorizontalHeader(ascent=data['ascender'],descent=data['descender'],lineGap=0)
 family=data['family'];ps=f'RFMSansStudy{v}R2-ExpandedBold'
 fb.setupNameTable({'familyName':family,'styleName':'Expanded Bold','fullName':family+' Expanded Bold','psName':ps,'uniqueFontIdentifier':ps+'-'+VERSION,'version':'Version '+VERSION,'typographicFamily':family+' Expanded','typographicSubfamily':'Bold'})
 fb.setupOS2(sTypoAscender=data['ascender'],sTypoDescender=data['descender'],sTypoLineGap=0,usWinAscent=data['ascender'],usWinDescent=-data['descender'],usWeightClass=700,usWidthClass=7,sxHeight=data['x_height'],sCapHeight=data['cap_height'],fsSelection=32)
 fb.setupPost();fb.setupMaxp();fb.font['head'].macStyle=1;fb.font['head'].created=fb.font['head'].modified=3800000000;fb.font.recalcTimestamp=False
 addOpenTypeFeaturesFromString(fb.font,(R/'sources'/f'{v}-kern.fea').read_text())
 out=R/'fonts'/f'{ps}.ttf';fb.font.save(out);web=TTFont(out,recalcTimestamp=False);web.flavor='woff2';web.save(out.with_suffix('.woff2'));return out

def preview(paths):
 im=Image.new('RGB',(2400,2200),'#10191b');d=ImageDraw.Draw(im);label=ImageFont.load_default(size=28)
 for col,v in enumerate('AB'):
  x=60+col*1200
  d.text((x,42),f'{v} / '+('TOURING' if v=='A' else 'FLOW')+' / R2 - 0.002',font=label,fill='#c6f75a')
  d.text((x,90),'ROUNDED SQUARE' if v=='A' else 'OVAL + CURVED DIAGONALS',font=ImageFont.load_default(size=21),fill='#a3b6b7')
 for row,s in enumerate(TEXTS):
  size=76
  while any(ImageFont.truetype(str(p),size).getlength(s)>1080 for p in paths):size-=1
  for col,p in enumerate(paths):
   x=60+col*1200;y=170+row*225;font=ImageFont.truetype(str(p),size)
   d.text((x,y),s,font=font,fill='#f7f5ef',features=['kern'])
   d.text((x,y+113),f'{size} px / same size in A and B',font=ImageFont.load_default(size=20),fill='#7c969b')
 for col,p in enumerate(paths):
  font=ImageFont.truetype(str(p),108);x=60+col*1200
  d.text((x,1780),'ОС РВ АЛМ',font=font,fill='#c6f75a')
  d.text((x,1975),'ORIGINAL OUTLINES / LIMITED COVERAGE / DESIGN PROTOTYPE',font=ImageFont.load_default(size=20),fill='#8ba2a4')
 im.save(R/'specimen.png')

def validate(paths):
 result={}
 for p in paths:
  f=TTFont(p);cmap=f.getBestCmap();assert set(cmap)==set(map(ord,CHARS))
  data=json.loads((R/'sources'/('A.json' if 'StudyA' in p.name else 'B.json')).read_text());curved=0
  for c in CHARS:
   if c==' ':continue
   glyph=f['glyf'][cmap[ord(c)]];assert glyph.numberOfContours>0;assert -250<=glyph.yMin and glyph.yMax<=950
   shape=path(data['glyphs'][cmap[ord(c)]]['commands']);assert shape.area>0
   if any(op=='curveTo' for op,_ in data['glyphs'][cmap[ord(c)]]['commands']):curved+=1
  w=TTFont(p.with_suffix('.woff2'));assert w.getBestCmap()==cmap
  kern={}
  font=ImageFont.truetype(str(p),100)
  for s in ['FA','ТА','RALLY FANS MAP','РАЛЛИ СОРТАВАЛА']:
   on=font.getlength(s,features=['kern']);off=font.getlength(s,features=['-kern']);assert on<off;kern[s]={'on':on,'off':off}
  result[p.name]={'mapped_characters':len(cmap),'curved_source_glyphs':curved,'vertical_bounds':'pass','woff2_roundtrip':'pass','kern_at_100px':kern,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
 (R/'validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
 # Compare actual source outlines rather than just names or hashes of whole fonts.
 a=json.loads((R/'sources/A.json').read_text())['glyphs'];b=json.loads((R/'sources/B.json').read_text())['glyphs']
 changed=[chr(a[n]['unicode']) for n in a if a[n]['commands']!=b[n]['commands']]
 assert len(changed)>=30
 (R/'direction-differences.json').write_text(json.dumps({'different_outlines':len(changed),'characters':changed,'same_character_set':True},ensure_ascii=False,indent=2))

def web():
 css='body{margin:30px;background:#10191b;color:#f7f5ef;font-family:system-ui}main{display:grid;grid-template-columns:1fr 1fr;gap:30px}p{font-size:clamp(18px,2.6vw,54px);font-weight:700}h2{color:#c6f75a}'
 for v in 'AB':
  b=base64.b64encode((R/'fonts'/f'RFMSansStudy{v}R2-ExpandedBold.woff2').read_bytes()).decode()
  css+=f'@font-face{{font-family:RFM{v};src:url(data:font/woff2;base64,{b}) format("woff2");font-weight:700}}.v{v} p{{font-family:RFM{v};font-synthesis:none}}'
 body='<h1>RFM Sans R2 / 0.002</h1><main>'+''.join(f'<section class="v{v}"><h2>{v} / '+('Touring' if v=='A' else 'Flow')+'</h2>'+''.join('<p>'+html.escape(t)+'</p>' for t in TEXTS)+'</section>' for v in 'AB')+'</main>'
 (R/'specimen.html').write_text('<!doctype html><html lang="ru"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>RFM Sans R2</title><style>'+css+'</style>'+body+'</html>')

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--seed',action='store_true');args=ap.parse_args()
 for d in ['sources','fonts','svg/A','svg/B']:(R/d).mkdir(parents=True,exist_ok=True)
 if args.seed:seed()
 paths=[build(v) for v in 'AB'];validate(paths);preview(paths);web()
 (R/'unicode-prototype.txt').write_text('\n'.join(f'U+{ord(c):04X}\t{c if c!=" " else "SPACE"}' for c in CHARS)+'\n')
 print('R2 built and validated:',len(CHARS),'characters per font')

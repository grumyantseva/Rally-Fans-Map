"""Rebuild twice, compare files, measure representative rasterized strokes."""
from pathlib import Path
import hashlib,json,subprocess,sys
from PIL import Image,ImageDraw,ImageFont
R=Path(__file__).resolve().parent

def hashes():
 return {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((R/'fonts').iterdir())}

subprocess.run([sys.executable,str(R/'build.py')],check=True)
a=hashes()
subprocess.run([sys.executable,str(R/'build.py')],check=True)
b=hashes();assert a==b,'Font files changed between identical builds'
(R/'repeatability.json').write_text(json.dumps({'identical_rebuild':True,'sha256':b},indent=2))

def runs(values):
 result=[];start=None
 for i,value in enumerate(values+[0]):
  if value>=128 and start is None:start=i
  elif value<128 and start is not None:result.append(i-start);start=None
 return result

checks={}
for v in 'AB':
 font=ImageFont.truetype(str(R/'fonts'/f'RFMSansStudy{v}R2-ExpandedBold.ttf'),1000)
 def raster(c):
  im=Image.new('L',(1300,1300));ImageDraw.Draw(im).text((100,1050),c,font=font,fill=255,anchor='ls');return im
 im=raster('О');bounds=im.getbbox();x=(bounds[0]+bounds[2])//2;y=(bounds[1]+bounds[3])//2
 horizontal=runs([im.getpixel((i,y)) for i in range(im.width)])
 vertical=runs([im.getpixel((x,i)) for i in range(im.height)])
 hn=raster('Н');hb=hn.getbbox()
 stem=runs([hn.getpixel((i,450)) for i in range(hn.width)])
 cross=runs([hn.getpixel(((hb[0]+hb[2])//2,i)) for i in range(hn.height)])
 assert len(horizontal)==len(vertical)==len(stem)==2
 assert all(129<=n<=135 for n in horizontal+vertical+stem)
 assert len(cross)==1 and 118<=cross[0]<=122
 checks[v]={'O_horizontal_scan_stems_px':horizontal,'O_vertical_scan_stems_px':vertical,'H_vertical_stems_px':stem,'H_crossbar_px':cross,'render_size_px':1000,'scope':'center-axis measurements only; not whole-font optical validation'}
(R/'stroke-checks.json').write_text(json.dumps(checks,indent=2))
print('Rebuild hashes, rendered stroke samples, coverage, bounds and kerning: passed')

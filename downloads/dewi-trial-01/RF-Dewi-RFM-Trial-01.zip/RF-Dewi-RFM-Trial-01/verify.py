from pathlib import Path
import argparse,subprocess,sys,json,hashlib,math
from PIL import Image,ImageDraw,ImageFont
from fontTools.ttLib import TTFont
R=Path(__file__).resolve().parent

def runs(row):
 out=[];start=None
 for i,val in enumerate(row+[0]):
  if val>=128 and start is None:start=i
  if val<128 and start is not None:out.append([start,i,i-start]);start=None
 return out

def raster(fp):
 im=Image.new('L',(1700,1300));ImageDraw.Draw(im).text((200,1000),'Н',font=ImageFont.truetype(str(fp),1000),fill=255,anchor='ls');return im

a=argparse.ArgumentParser();a.add_argument('--input-dir',type=Path,required=True);args=a.parse_args()
command=[sys.executable,str(R/'build.py'),'--input-dir',str(args.input_dir)]
subprocess.run(command,check=True)
files=list((R/'fonts').iterdir());before={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in files}
checks=[]
for case in json.loads((R/'report.json').read_text()):
 original=args.input_dir/case['input'];trial=R/'fonts'/case['output'];fi,fo=TTFont(original),TTFont(trial)
 assert hashlib.sha256(original.read_bytes()).hexdigest()==case['input_sha256']
 for ch in ['А','В','О','Р','е','0','6','8','9']:
  assert fi['glyf'][fi.getBestCmap()[ord(ch)]].numberOfContours==fo['glyf'][fo.getBestCmap()[ord(ch)]].numberOfContours
 check={'font':case['output'],'representative_counter_counts_preserved':True}
 for fp,label in [(original,'before'),(trial,'after')]:
  im=raster(fp);row=runs([im.getpixel((x,850)) for x in range(im.width)]);assert len(row)==2
  check[label+'_H_stem_widths_at_1000px']=[r[2] for r in row]
  check[label+'_RALLY_advance']=ImageFont.truetype(str(fp),1000).getlength('RALLY FANS MAP')
  if not case['parameters']['grow']:
   xs=[runs([im.getpixel((x,1000-y)) for x in range(im.width)])[0][0] for y in [100,600]]
   check[label+'_measured_angle_degrees']=round(math.degrees(math.atan2(xs[1]-xs[0],500)),3)
 if case['parameters']['grow']:
  assert all(a>b for a,b in zip(check['after_H_stem_widths_at_1000px'],check['before_H_stem_widths_at_1000px']))
  assert check['after_RALLY_advance']>check['before_RALLY_advance']
 else:
  assert 8.7<=check['before_measured_angle_degrees']<=9.3
  assert 5.7<=check['after_measured_angle_degrees']<=6.3
 checks.append(check)
subprocess.run(command,check=True)
after={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in files};assert before==after
(R/'checks.json').write_text(json.dumps({'repeatable':True,'originals_unchanged':True,'details':checks},indent=2))
print('Originals, rebuild, representative counters, increased width/weight and reduced angle: passed')

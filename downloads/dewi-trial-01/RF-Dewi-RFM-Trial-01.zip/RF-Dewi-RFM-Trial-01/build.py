"""RF Dewi user-supplied font adjustment trial; requires the three original TTFs.
Does not read or write any file outside the given input directory and this project.
Original attribution and embedding flags are preserved. Outputs are derivative trials.
"""
from pathlib import Path
import argparse, json, hashlib, math, copy
import pathops as po
from fontTools.ttLib import TTFont,newTable
from fontTools import subset
from fontTools.pens.recordingPen import DecomposingRecordingPen,RecordingPen
from fontTools.pens.ttGlyphPen import TTGlyphPen
from fontTools.pens.cu2quPen import Cu2QuPen
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.ttLib.tables import otTables
from fontTools.ttLib.tables.otBase import ValueRecord
from PIL import Image,ImageDraw,ImageFont
R=Path(__file__).resolve().parent
TEXTS=['RALLY FANS MAP','РАЛЛИ СОРТАВАЛА','КОМПАНЬОН','ПРОГРАММА НА СЕГОДНЯ','Альметьевск','0123456789','25–26 СЕНТЯБРЯ']
CHARS=sorted(set(''.join(TEXTS)),key=ord)
CASES=[{'key':'ExpandedBold','filename':'RFDewiExpanded-Bold.ttf','family':'RF Dewi RFM Trial 01 Expanded','legacy_family':'RF Dewi RFM Trial 01 Expanded','style':'Bold','legacy_style':'Bold','sx':1.05,'grow':10,'angle':0},
{'key':'ExtendedBlack','filename':'RFDewiExtended-Black.ttf','family':'RF Dewi RFM Trial 01 Extended','legacy_family':'RF Dewi RFM Trial 01 Extended Black','style':'Black','legacy_style':'Regular','sx':1.05,'grow':6,'angle':0},
{'key':'ExpandedBlackItalic','filename':'RFDewiExpanded-BlackItalic.ttf','family':'RF Dewi RFM Trial 01 Expanded','legacy_family':'RF Dewi RFM Trial 01 Expanded Black','style':'Black Italic','legacy_style':'Italic','sx':1,'grow':0,'angle':-6}]

def outline(font,name):
 rec=DecomposingRecordingPen(font.getGlyphSet());font.getGlyphSet()[name].draw(rec)
 p=po.Path();rec.replay(p.getPen());return p

def fix_layout(obj,sx,sy,tx,ty,shear,seen=None):
 if seen is None:seen=set()
 if id(obj) in seen:return
 seen.add(id(obj))
 if isinstance(obj,otTables.Anchor):
  x,y=obj.XCoordinate,obj.YCoordinate
  obj.XCoordinate=round(sx*x+shear*y+tx);obj.YCoordinate=round(sy*y+ty)
  if getattr(obj,'Format',None)==2:obj.Format=1;obj.__dict__.pop('AnchorPoint',None)
 elif isinstance(obj,ValueRecord):
  x,y=getattr(obj,'XPlacement',0),getattr(obj,'YPlacement',0)
  if hasattr(obj,'XPlacement'):obj.XPlacement=round(sx*x+shear*y)
  if hasattr(obj,'YPlacement'):obj.YPlacement=round(sy*y)
  if hasattr(obj,'XAdvance'):obj.XAdvance=round(obj.XAdvance*sx)
  if hasattr(obj,'YAdvance'):obj.YAdvance=round(obj.YAdvance*sy)
  # Pixel-size device deltas refer to the original hinted geometry.
  for key in list(vars(obj)):
   if 'Device' in key:setattr(obj,key,None)
 elif isinstance(obj,dict):
  for value in obj.values():fix_layout(value,sx,sy,tx,ty,shear,seen)
 elif isinstance(obj,(list,tuple)):
  for value in obj:fix_layout(value,sx,sy,tx,ty,shear,seen)
 elif hasattr(obj,'__dict__'):
  for value in vars(obj).values():fix_layout(value,sx,sy,tx,ty,shear,seen)

def build(case,src):
 inp=src/case['filename'];rawhash=hashlib.sha256(inp.read_bytes()).hexdigest()
 f=TTFont(inp,recalcTimestamp=False);original_names={str(i):f['name'].getDebugName(i) for i in [0,1,2,5,6,8,9,13,14,16,17]}
 assert set(map(ord,CHARS)).issubset(f.getBestCmap())
 old={'glyphs':len(f.getGlyphOrder()),'codepoints':len(f.getBestCmap()),'italic_angle':f['post'].italicAngle,'weight':f['OS/2'].usWeightClass,'width':f['OS/2'].usWidthClass,'upm':f['head'].unitsPerEm,'cap_height':f['OS/2'].sCapHeight,'x_height':f['OS/2'].sxHeight,'fsType':f['OS/2'].fsType}
 
 if 'FFTM' in f:del f['FFTM']
 opt=subset.Options();opt.hinting=False;opt.glyph_names=True;opt.name_IDs=['*'];opt.name_legacy=True;opt.name_languages=['*'];opt.layout_features=['kern'];opt.recalc_timestamp=False
 ss=subset.Subsetter(options=opt);ss.populate(unicodes=list(map(ord,CHARS)));ss.subset(f)
 sx=case['sx'];r=case['grow'];cap=old['cap_height'];sy=cap/(cap+2*r);ty=r*sy
 shear=math.tan(math.radians(-case['angle']))-math.tan(math.radians(-old['italic_angle']))
 glyphs={};metrics={};source={};svgdir=R/'svg'/case['key'];svgdir.mkdir(parents=True,exist_ok=True)
 allbounds=[]
 for name in f.getGlyphOrder():
  p=outline(f,name);advance,lsb=f['hmtx'][name]
  # Width first; add a controlled normal offset only to the upright trials.
  p=p.transform(sx,0,0,1,0,0)
  if r and list(p):
   edge=p.transform(1,0,0,1,0,0);edge.stroke(2*r,po.LineCap.BUTT_CAP,po.LineJoin.ROUND_JOIN,4);edge.convertConicsToQuads(.1)
   p=po.op(p,edge,po.PathOp.UNION,clockwise=True)
   p=p.transform(1,0,0,sy,r,ty)
  elif shear:p=p.transform(1,0,shear,1,0,0)
  if list(p):p=po.simplify(p,clockwise=True)
  rec=RecordingPen();p.draw(rec);pen=TTGlyphPen(None)
  rec.replay(Cu2QuPen(pen,max_err=.35));glyph=pen.glyph();glyphs[name]=glyph
  if list(p):
   bounds=p.bounds;lsb=round(bounds[0]);allbounds.append(bounds)
  else:bounds=None;lsb=0
  newadv=round(advance*sx+(2*r if advance else 0))
  metrics[name]=(newadv,lsb)
  source[name]={'advance':newadv,'lsb':lsb,'commands':rec.value}
  svg=SVGPathPen(None);rec.replay(svg)
  safe=name.replace('/','_')
  (svgdir/f'{safe}.svg').write_text(f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="-200 -1000 {newadv+400} 1300"><title>{name}</title><path transform="scale(1,-1)" d="{svg.getCommands()}"/></svg>')
 f['glyf'].glyphs=glyphs;f['glyf'].glyphOrder=f.getGlyphOrder();f['hmtx'].metrics=metrics
 for table in ['GPOS','GDEF']:
  if table in f:fix_layout(f[table].table,sx,sy,r,ty,shear)
 # Set all language/platform copies of names consistently; retain RF authorship/copyright.
 names={1:case['legacy_family'],2:case['legacy_style'],3:'RF-Dewi-RFM-Trial01-'+case['key']+'-0.001',4:case['family']+' '+case['style'],5:'Version 0.001; RF Dewi modification trial 01',6:'RFDewiRFMTrial01-'+case['key'],16:case['family'],17:case['style'],10:'Personal adjustment trial based on user-supplied RF Dewi. Original design attribution retained; not an independent RFM typeface.'}
 f['name'].names=[n for n in f['name'].names if n.nameID not in names and n.nameID not in [18,21,22,25]]
 for nid,value in names.items():
  f['name'].setName(value,nid,3,1,0x409);f['name'].setName(value,nid,1,0,0)
 f['post'].italicAngle=case['angle']
 f['OS/2'].sxHeight=round((old['x_height']+2*r)*sy)
 f['OS/2'].recalcAvgCharWidth(f)
 if case['angle']:
  f['hhea'].caretSlopeRise=1000;f['hhea'].caretSlopeRun=round(1000*math.tan(math.radians(-case['angle'])))
 else:f['hhea'].caretSlopeRise=1;f['hhea'].caretSlopeRun=0
 # Keep original weight/style flags and cap height. These are visual trials, not new weight classes.
 maxy=max(b[3] for b in allbounds);miny=min(b[1] for b in allbounds)
 assert maxy<=f['OS/2'].usWinAscent and miny>=-f['OS/2'].usWinDescent
 for table in ['DSIG','FFTM','hdmx','LTSH','VDMX']:
  if table in f:del f[table]
 f['head'].created=f['head'].modified=3800000000;f.recalcTimestamp=False
 out=R/'fonts'/('RFDewiRFMTrial01-'+case['key']+'.ttf');f.save(out)
 web=TTFont(out,recalcTimestamp=False);web.flavor='woff2';web.save(out.with_suffix('.woff2'))
 output=TTFont(out);assert set(output.getBestCmap())==set(map(ord,CHARS))
 assert output['OS/2'].fsType==old['fsType']
 assert output['name'].getDebugName(0)==original_names['0']
 assert output['name'].getDebugName(9)==original_names['9']
 assert abs(output['post'].italicAngle-case['angle'])<.001
 (R/'sources'/f'{case["key"]}.json').write_text(json.dumps({'derived_from':case['filename'],'source_sha256':rawhash,'parameters':case,'source_names':original_names,'glyphs':source},ensure_ascii=False,indent=2))
 return out,{'input':case['filename'],'input_sha256':rawhash,'original':old,'parameters':case,'shear_delta':shear,'vertical_compensation':sy,'output':out.name,'output_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'coverage':len(output.getBestCmap()),'glyphs':len(output.getGlyphOrder()),'bounds_y':[miny,maxy],'author_copyright_preserved':True,'woff2_roundtrip':TTFont(out.with_suffix('.woff2')).getBestCmap()==output.getBestCmap()}

def preview(cases,src,paths):
 im=Image.new('RGB',(2400,3320),'#11191b');d=ImageDraw.Draw(im);label=ImageFont.load_default(size=27)
 for block,(case,new) in enumerate(zip(cases,paths)):
  base=block*1100
  title=case['key']+' / '+('9 deg -> 6 deg' if case['grow']==0 else f'width +5%, outline +{case["grow"]} units per side')
  d.text((55,base+35),title,font=label,fill='#c6f75a')
  d.text((55,base+85),'ORIGINAL',font=label,fill='#8aa0a5');d.text((1255,base+85),'TRIAL 01',font=label,fill='#c6f75a')
  for row,s in enumerate(TEXTS):
   size=60
   while any(ImageFont.truetype(str(p),size).getlength(s)>1070 for p in [src/case['filename'],new]):size-=1
   for col,fp in enumerate([src/case['filename'],new]):
    font=ImageFont.truetype(str(fp),size);d.text((55+col*1200,base+155+row*125),s,font=font,fill='#f6f4ee',features=['kern'])
  d.text((55,base+1055),'SAME SIZE IN EACH PAIR / ORIGINAL RF DEWI vs DERIVED TRIAL / LIMITED CHARACTER SET',font=ImageFont.load_default(size=20),fill='#83999f')
 im.save(R/'comparison.png')
 # Each face has its own compact downloadable preview.
 for i,c in enumerate(cases):im.crop((0,i*1100,2400,(i+1)*1100)).save(R/f'{c["key"]}-comparison.png')

if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('--input-dir',type=Path,required=True);args=a.parse_args()
 for p in ['fonts','sources','svg']:(R/p).mkdir(exist_ok=True)
 paths=[];report=[]
 for case in CASES:
  out,info=build(case,args.input_dir);paths.append(out);report.append(info)
 preview(CASES,args.input_dir,paths)
 (R/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
 (R/'unicode-prototype.txt').write_text('\n'.join(f'U+{ord(c):04X}\t{c if c!=" " else "SPACE"}' for c in CHARS)+'\n')
 print('Built three derivative trials; originals unchanged; 47 characters per font')

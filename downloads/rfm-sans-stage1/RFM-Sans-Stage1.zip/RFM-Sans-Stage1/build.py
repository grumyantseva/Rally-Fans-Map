"""Original RFM outline study. No external font outlines are read."""
from pathlib import Path
import json, math, hashlib, shutil
from shapely.geometry import Polygon, LineString, box
from shapely.ops import unary_union
from shapely.geometry.polygon import orient
from fontTools.fontBuilder import FontBuilder
from fontTools.pens.ttGlyphPen import TTGlyphPen
from fontTools.ttLib import TTFont
from fontTools.feaLib.builder import addOpenTypeFeaturesFromString
from PIL import Image, ImageDraw, ImageFont

ROOT=Path(__file__).resolve().parent
TEXTS=['RALLY FANS MAP','РАЛЛИ СОРТАВАЛА','КОМПАНЬОН','ПРОГРАММА НА СЕГОДНЯ','Альметьевск','0123456789','25–26 СЕНТЯБРЯ']
FULL=' '+''.join(chr(x) for x in range(33,127))+''.join(chr(x) for x in range(0x410,0x450))+'Ёё«»“”‘’–—№₽−°\u00a0'
CHARS=sorted(set(''.join(TEXTS)),key=ord)
# Skeleton coordinates are original design inputs in em units, cap height 700.
# Rounds use independent outer and inner chamfered superellipse-like polygons.
S={
'A': [[(0,0),(290,700),(490,700),(780,0)],[(150,270),(630,270)]],
'F': [[(0,0),(0,700),(690,700)],[(0,370),(580,370)]],
'L': [[(0,700),(0,0),(680,0)]],
'M': [[(0,0),(0,700),(125,700),(400,220),(675,700),(800,700),(800,0)]],
'N': [[(0,0),(0,700),(95,700),(685,0),(780,0),(780,700)]],
'Y': [[(0,700),(370,330),(740,700)],[(370,330),(370,0)]],
'Т': [[(0,700),(760,700)],[(380,700),(380,0)]],
'Г': [[(0,0),(0,700),(690,700)]],
'П': [[(0,0),(0,700),(760,700),(760,0)]],
'И': [[(0,700),(0,0),(90,0),(670,700),(760,700),(760,0)]],
'Л': [[(0,0),(125,0),(310,700),(760,700),(760,0)]],
'К': [[(0,0),(0,700)],[(740,700),(330,350),(0,350)],[(330,350),(760,0)]],
'Е': [[(700,700),(0,700),(0,0),(700,0)],[(0,350),(600,350)]],
'Д': [[(90,0),(230,700),(680,700),(680,0)],[(0,-150),(0,0),(800,0),(800,-150)]],
'1': [[(65,545),(300,700),(380,700),(380,0)],[(80,0),(690,0)]],
'4': [[(575,0),(575,700),(440,700),(0,220),(760,220)]],
'7': [[(0,700),(760,700),(280,0)]],
'–': [[(0,295),(610,295)]],
}
# Prototype lowercase has its own x-height, branching and width, not scaled caps.
LOW={
'л':[[(0,0),(95,0),(240,500),(540,500),(540,0)]],
'м':[[(0,0),(0,500),(80,500),(310,150),(540,500),(620,500),(620,0)]],
'т':[[(0,500),(600,500)],[(300,500),(300,0)]],
'к':[[(0,0),(0,500)],[(570,500),(240,240),(0,240)],[(240,240),(590,0)]],
}
S.update(LOW)
ALIAS={'Р':'P','А':'A','М':'M','Н':'H','О':'O','С':'C','В':'B'}

def roundrect(x,y,w,h,r,variant):
 r=min(r,w/2,h/2)
 if variant=='A':
  pts=[(x+r,y),(x+w-r,y),(x+w,y+r),(x+w,y+h-r),(x+w-r,y+h),(x+r,y+h),(x,y+h-r),(x,y+r)]
 else:
  pts=[]
  for cx,cy,start in [(x+w-r,y+r,-90),(x+w-r,y+h-r,0),(x+r,y+h-r,90),(x+r,y+r,180)]:
   for i in range(13):
    a=math.radians(start+i*90/12); pts.append((cx+r*math.cos(a),cy+r*math.sin(a)))
 return Polygon(pts)

def design(c,v):
 t=(140 if v=='A' else 136) if c not in ['л','ь','м','е','т','в','с','к'] else 90
 c=ALIAS.get(c,c)
 def stroke(points):return LineString(points).buffer(t/2,cap_style=2,join_style=2)
 def ring(x,y,w,h):
  return roundrect(x,y,w,h,150 if v=='A' else 215,v).difference(roundrect(x+t,y+t,w-2*t,h-2*t,75 if v=='A' else 115,v))
 def bowl(x,y,w,h):return ring(x,y,w,h)
 if c in S: g=unary_union([stroke(p) for p in S[c]]).intersection(box(-200,-150 if c=='Д' else 0,1200,500 if c in LOW else 700))
 elif c=='H':g=unary_union([box(0,0,t,700),box(670,0,670+t,700),box(0,292,784,408)])
 elif c in ['O','0']:g=ring(0,-12,790 if c=='O' else 720,724)
 elif c=='C':g=ring(0,-12,790,724).difference(box(495,170,900,530))
 elif c=='S':
  g=unary_union([bowl(0,288,750,424).difference(box(510,260,850,490)),bowl(0,-12,750,424).difference(box(-10,210,240,440))])
 elif c=='Б':g=unary_union([box(0,0,t,700),box(0,590,710,700),bowl(0,-8,730,420)])
 elif c in ['P','R','B','Ь','Я','ь','в']:
  lower=c in ['ь','в']; h=500 if lower else 700; w=570 if lower else 730
  stem=box(0,0,t,h)
  if c in ['P','R','Я']:g=unary_union([stem,bowl(0,285,w,415)])
  elif c in ['Ь','ь']:g=unary_union([stem,bowl(0,-8,w, int(h*.60)+8)])
  else:g=unary_union([stem,bowl(0,-8,w,h*.53+8),bowl(0,h*.47,w-25,h*.53)])
  if c=='R':g=unary_union([g,stroke([(370,300),(760,0)])])
  if c=='Я':
   from shapely.affinity import scale
   g=unary_union([scale(g,xfact=-1,yfact=1,origin=(w/2,0)),stroke([(360,300),(15,0)])]).intersection(box(-100,0,900,700))
 elif c in ['2','3','5','6','8','9']:
  if c=='8':g=unary_union([bowl(0,-12,720,410),bowl(15,312,690,400)])
  elif c=='6':g=unary_union([bowl(0,-12,720,425),bowl(0,275,720,437).difference(box(300,260,850,510))])
  elif c=='9':
   from shapely.affinity import rotate
   g=rotate(design('6',v)[0],180,origin=(360,350))
  elif c=='3':g=unary_union([bowl(0,-12,720,414),bowl(0,302,720,410)]).difference(box(-10,120,235,580))
  elif c=='5':g=unary_union([stroke([(710,655),(57,655),(57,375),(475,375)]),bowl(0,-12,720,425).difference(box(-10,175,245,350))])
  else:g=unary_union([bowl(0,288,720,424).difference(box(-10,260,230,470)).intersection(box(-100,435,850,750)),stroke([(650,465),(650,435),(70,70),(720,70)])])
 elif c=='е':g=unary_union([ring(0,-10,600,520).difference(box(370,100,700,210)),box(40,220,580,310)])
 elif c=='с':g=ring(0,-10,600,520).difference(box(365,120,700,380))
 else:raise ValueError(c)
 # Baseline strokes get flat outer extrema; rounded bowls retain overshoot.
 minx,miny,maxx,maxy=g.bounds
 from shapely.affinity import translate
 g=translate(g,xoff=65-minx)
 width=round(maxx-minx+130)
 return g,width

def contours(g):
 polys=[g] if g.geom_type=='Polygon' else list(g.geoms)
 result=[]
 for p in polys:
  p=orient(p,sign=-1)
  for ring in [p.exterior,*p.interiors]:result.append([[round(x),round(y)] for x,y in list(ring.coords)[:-1]])
 return result

def seed():
 for v in ['A','B']:
  data={'family':f'RFM Sans Study {v}','style':'Expanded Bold','upm':1000,'ascender':950,'descender':-250,'glyphs':{}}
  for c in CHARS:
   g,w=(None,340) if c==' ' else design(c,v)
   data['glyphs'][f'uni{ord(c):04X}']={'unicode':ord(c),'advance':w,'contours':[] if g is None else contours(g)}
  (ROOT/'sources'/f'{v}.json').write_text(json.dumps(data,ensure_ascii=False,indent=2))

def build(v):
 data=json.loads((ROOT/'sources'/f'{v}.json').read_text()); glyphs=data['glyphs']
 order=['.notdef',*glyphs]; fb=FontBuilder(1000,isTTF=True);fb.setupGlyphOrder(order)
 fb.setupCharacterMap({g['unicode']:name for name,g in glyphs.items()})
 pen=TTGlyphPen(None)
 for pts in [[(70,0),(70,700),(650,700),(650,0)],[(180,110),(540,110),(540,590),(180,590)]]:
  pen.moveTo(pts[0]);[pen.lineTo(p) for p in pts[1:]];pen.closePath()
 outlines={'.notdef':pen.glyph()}; metrics={'.notdef':(720,70)}
 svgdir=ROOT/'svg'/v;svgdir.mkdir(parents=True,exist_ok=True)
 for name,g in glyphs.items():
  pen=TTGlyphPen(None)
  for pts in g['contours']:
   pen.moveTo(pts[0]);[pen.lineTo(p) for p in pts[1:]];pen.closePath()
  outlines[name]=pen.glyph();metrics[name]=(g['advance'],min((x for pts in g['contours'] for x,y in pts),default=0))
  d=' '.join('M'+' L'.join(f'{x} {y}' for x,y in pts)+' Z' for pts in g['contours'])
  (svgdir/f'{name}.svg').write_text(f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 -950 {g["advance"]} 1200"><title>{name}</title><path transform="scale(1,-1)" d="{d}"/></svg>')
 fb.setupGlyf(outlines);fb.setupHorizontalMetrics(metrics);fb.setupHorizontalHeader(ascent=950,descent=-250,lineGap=0)
 fb.setupNameTable({'familyName':data['family'],'styleName':'Expanded Bold','uniqueFontIdentifier':f'RFM-Study-{v}-0.001','fullName':data['family']+' Expanded Bold','psName':f'RFMSansStudy{v}-ExpandedBold','version':'Version 0.001','typographicFamily':data['family']+' Expanded','typographicSubfamily':'Bold'})
 fb.setupOS2(sTypoAscender=950,sTypoDescender=-250,sTypoLineGap=0,usWinAscent=950,usWinDescent=250,usWeightClass=700,usWidthClass=7,sxHeight=500,sCapHeight=700,fsSelection=32)
 fb.setupPost();fb.setupMaxp();fb.font['head'].macStyle=1;fb.font['head'].created=fb.font['head'].modified=3800000000
 pairs={'RA':-35,'LY':-65,'FA':-45,'MA':-20,'АЛ':-35,'ЛИ':-20,'ТА':-65,'ГА':-50,'РА':-35,'АТ':-50,'ДН':-15,'ГР':-15,'СО':-15,'КО':-20,'ЛЬ':-15,'НА':-15,'РЯ':-20}
 pairs={p:n for p,n in pairs.items() if all(c in CHARS for c in p)}
 feature='languagesystem DFLT dflt; languagesystem cyrl dflt; languagesystem latn dflt; feature kern {\n'+''.join(f'pos uni{ord(p[0]):04X} uni{ord(p[1]):04X} {n};\n' for p,n in pairs.items())+'} kern;'
 feature_path=ROOT/'sources'/f'{v}-kern.fea'
 if feature_path.exists(): feature=feature_path.read_text()
 else: feature_path.write_text(feature)
 addOpenTypeFeaturesFromString(fb.font,feature)
 fb.font.recalcTimestamp=False
 path=ROOT/'fonts'/f'RFMSansStudy{v}-ExpandedBold.ttf';fb.font.save(path)
 font=TTFont(path,recalcTimestamp=False);font.flavor='woff2';font.save(path.with_suffix('.woff2'))
 return path,pairs

def preview(paths):
 canvas=Image.new('RGB',(2400,1900),'#11191a');draw=ImageDraw.Draw(canvas)
 label=ImageFont.load_default(size=25)
 for col,(v,path) in enumerate(zip(['A','B'],paths)):
  x=65+col*1190;draw.text((x,45),f'RFM SANS / {v} / EXPANDED BOLD / 0.001',font=label,fill='#b9f24b')
  for i,s in enumerate(TEXTS):
   size=66
   font=ImageFont.truetype(str(path),size)
   while draw.textlength(s,font=font)>1070:
    size-=1;font=ImageFont.truetype(str(path),size)
   y=140+i*225
   draw.text((x,y),s,font=font,fill='#f5f5ee',features=['kern'])
   draw.text((x,y+105),f'{size} px',font=label,fill='#76908b')
 draw.text((65,1800),'ORIGINAL OUTLINE STUDY / LIMITED CHARACTER SET / NOT A RELEASE FONT',font=label,fill='#b9f24b')
 canvas.save(ROOT/'specimen.png')

def validate(paths):
 results={}
 for path in paths:
  f=TTFont(path); cmap=f.getBestCmap(); assert set(cmap)==set(map(ord,CHARS))
  assert all(f['glyf'][cmap[ord(c)]].numberOfContours>0 for c in CHARS if c!=' ')
  bounds=[]
  for name in f.getGlyphOrder():
   g=f['glyf'][name]
   if g.numberOfContours:
    assert g.yMin>=-250 and g.yMax<=950
    bounds.append([name,g.xMin,g.yMin,g.xMax,g.yMax])
  w=TTFont(path.with_suffix('.woff2')); assert w.getBestCmap()==cmap
  # Every source contour remains a valid filled polygon; no empty alphabet placeholders.
  results[path.name]={'mapped_characters':len(cmap),'nonempty_glyphs':len(bounds),'missing_in_samples':[],'woff2_roundtrip':True,'vertical_bounds_pass':True,'tables':list(f.keys()),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
 (ROOT/'validation.json').write_text(json.dumps(results,indent=2))

if __name__=='__main__':
 import argparse
 a=argparse.ArgumentParser();a.add_argument('--seed',action='store_true');args=a.parse_args()
 for d in ['sources','fonts','svg']: (ROOT/d).mkdir(exist_ok=True)
 if args.seed:seed()
 paths=[build(v)[0] for v in ['A','B']];validate(paths);preview(paths)
 (ROOT/'sample-texts.json').write_text(json.dumps(TEXTS,ensure_ascii=False,indent=2))
 (ROOT/'unicode-prototype.txt').write_text('\n'.join(f'U+{ord(c):04X}\t{c if c!=" " else "SPACE"}' for c in CHARS)+'\n')
 (ROOT/'unicode-target.txt').write_text('\n'.join(f'U+{ord(c):04X}\t{c if c not in " \u00a0" else "SPACE"}' for c in sorted(set(FULL),key=ord))+'\n')
 print('Built and validated A and B:',len(CHARS),'mapped characters each')
